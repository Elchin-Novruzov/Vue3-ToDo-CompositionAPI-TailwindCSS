<script>
import { computed, reactive, toRefs } from 'vue'
import { v4 as uuid } from 'uuid'
import IconCheckCircle from './components/IconCheckCircle.vue'
import IconCircle from './components/IconCircle.vue'
import IconDelete from './components/IconDelete.vue'
import IconEdit from './components/IconEdit.vue'
import MainHero from './components/MainHero.vue'
import TabNav from './components/TabNav.vue'



export default {
  name: 'App',
  components: {
    IconCheckCircle,
    IconCircle,
    IconDelete,
    IconEdit,
    MainHero,
    TabNav
    

  },
  setup() {
    const state = reactive({
      currentView: 'All',
      newTaskInput: '',
      taskList: []
    })

    const taskLists = reactive({
      all: computed(() => state.taskList),
      current: computed(() =>
        state.taskList.filter(item => item.complete === false)
      ),
      completed: computed(() =>
        state.taskList.filter(item => item.complete === true)
      )
    })

    const taskListOverview = reactive([
      { name: 'All', length: computed(() => taskLists.all.length) },
      { name: 'Current', length: computed(() => taskLists.current.length) },
      { name: 'Completed', length: computed(() => taskLists.completed.length) }
    ])

    const tasksInView = computed(() => {
      if (state.currentView === 'Current') {
        return state.taskList.filter(item => item.complete === false)
      } else if (state.currentView === 'Completed') {
        return state.taskList.filter(item => item.complete === true)
      } else {
        return state.taskList
      }
    })

    const addTask = () => {
      state.taskList.push({
        id: uuid(),
        complete: false,
        edit: false,
        label: state.newTaskInput
      })
      state.newTaskInput = ''
    }

    const toggleEdit = taskId => {
      const taskIndex = state.taskList.findIndex(task => task.id === taskId)
      state.taskList[taskIndex].edit = !state.taskList[taskIndex].edit
    }

    const deleteTask = taskId => {
      const taskIndex = state.taskList.findIndex(task => task.id === taskId)
      state.taskList.splice(taskIndex, 1)
    }

    const setView = viewLabel => {
      state.currentView = viewLabel
    }

    return {
      ...toRefs(state),
      addTask,
      deleteTask,
      setView,
      tasksInView,
      toggleEdit,
      taskListOverview
    }
  }
}
</script>

<template>
  <main class="main-wrapper">
    <MainHero />
    <div class="new-task-wrapper">
      <input
        type="text"
        placeholder="Type a new todo item"
        class="new-task-input"
        v-model="newTaskInput"
        @keyup.enter="addTask"
      />
      <button class="new-task-button" @click="addTask">+ Add</button>
    </div>
    <TabNav
      :currentView="currentView"
      :taskListOverview="taskListOverview"
      @update-current-view="setView"
    />
    <ul class="p-0">
      <li
        v-for="taskItem in tasksInView"
        :key="taskItem.id"
        class="task-list-item"
      >
        <div class="task-list-checkbox-wrapper">
          <IconCheckCircle v-show="taskItem.complete" />
          <IconCircle v-show="!taskItem.complete" />
          <input
            type="checkbox"
            v-model="taskItem.complete"
            :checked="taskItem.complete"
            class="task-list-checkbox"
          />
        </div>
        <input
          v-if="taskItem.edit"
          class="task-list-edit-input"
          type="text"
          v-model="taskItem.label"
        />
        <p
          v-else
          class="task-list-text"
          :class="taskItem.complete ? 'is-complete' : ''"
        >
          {{ taskItem.label }}
        </p>
        <div class="task-list-cta">
          <p>
            <IconEdit
              class="task-list-cta-icon opacity-0 transition-[0.2s] duration-[opacity] ease-[ease-in]"
              @click="toggleEdit(taskItem.id)"
            /><span class="sr-only">Edit</span>
          </p>
          <p>
            <IconDelete
              class="task-list-cta-icon opacity-0 transition-[0.2s] duration-[opacity] ease-[ease-in]"
              @click="deleteTask(taskItem.id)"
            /><span class="sr-only">Delete</span>
          </p>
        </div>
      </li>
    </ul>
  </main>
</template>

<style>
@import 'tailwindcss/base';
@import 'tailwindcss/components';
@import 'tailwindcss/utilities';
@import './index.css';

html {
  @apply bg-[#fbfbfb] m-4;
  
}
.task-list-checkbox-wrapper {
  @apply relative flex items-center justify-center;
}
.task-list-checkbox {
  @apply absolute left-[-3px] opacity-0 bottom-0.5;
}

.task-list-cta-icon .icon-object {
  @apply fill-[#2d2d2d];
}
.task-list-cta-icon:hover .icon-object {
  @apply fill-[#0728bf];
}
.task-list-item {
  @apply border shadow-[2px_2px_8px_0_#cfcfcf] flex items-center mb-4 px-4 py-4 rounded-lg border-solid border-[#f6f6f6] hover:border hover:border-solid hover:border-[#0631f8];
}
.task-list-item:hover .task-list-cta-icon,
.task-list-item:focus .task-list-cta-icon {
  @apply opacity-100;
}
.task-list-cta {
  @apply flex gap-x-4;
}
.task-list-edit-input,
.task-list-text {
  @apply font-[bold] flex-1 text-base ml-3 border-0;
}
.task-list-text.is-complete {
  @apply text-[#6b6b6b] line-through;
}
.new-task-wrapper {
  @apply flex;
}
.new-task-input {
  @apply font-semibold text-[#2d2d2d] flex-1 border shadow-[2px_2px_8px_0_#c0c0c0] tracking-[1px] text-base p-4 rounded-tl-lg rounded-bl-lg border-solid border-[#f6f6f6] hover:border hover:border-solid hover:border-[#0631f8];
}
.new-task-input::placeholder {
  @apply text-[#959595];
}
.new-task-button {
  @apply bg-[#0631f8] text-white font-black transition-[0.2s] duration-[background] ease-[ease-in] text-base px-6 py-[18px] rounded-tr-lg rounded-br-lg border-0 hover:bg-[#082ac9];
}
.main-wrapper {
  @apply max-w-[900px] mx-auto my-0;
}
</style>
