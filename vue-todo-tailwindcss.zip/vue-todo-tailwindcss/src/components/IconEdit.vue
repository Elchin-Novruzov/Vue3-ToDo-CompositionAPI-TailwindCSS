<script>
export default {}
</script>

<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="16"
    height="17"
    viewBox="0 0 16 17"
  >
    <g fill="none" fill-rule="evenodd">
      <g class="icon-object">
        <g>
          <path
            d="M14.709.679c-.35-.357-.829-.557-1.328-.557-.499 0-.977.2-1.327.557l-.804.818 3.27 3.332.848-.863c.71-.725.712-1.884.005-2.61l-.664-.677zM1.353 11.578L.098 16.192 4.616 14.917 14.081 5.277 10.811 1.945z"
            transform="translate(-748 -381) translate(748 381)"
          />
        </g>
      </g>
    </g>
  </svg>
</template>

<style></style>
