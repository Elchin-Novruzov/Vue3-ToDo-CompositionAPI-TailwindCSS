<script>
export default {}
</script>

<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="15"
    height="15"
    viewBox="0 0 15 15"
  >
    <g fill="none" fill-rule="evenodd">
      <g fill="#6B6B6B" fill-rule="nonzero">
        <g>
          <path
            d="M7.25 14.5c4.004 0 7.25-3.246 7.25-7.25S11.254 0 7.25 0 0 3.246 0 7.25s3.246 7.25 7.25 7.25zM3.487 7.441c.257-.255.672-.255.929 0l1.516 1.516 3.816-3.816c.261-.224.651-.209.895.034.243.244.258.634.034.895l-4.284 4.284c-.257.256-.672.256-.93 0L3.488 8.377c-.125-.124-.195-.292-.195-.468 0-.176.07-.344.195-.468z"
            transform="translate(-227 -521) translate(227 521)"
          />
        </g>
      </g>
    </g>
  </svg>
</template>

<style></style>
