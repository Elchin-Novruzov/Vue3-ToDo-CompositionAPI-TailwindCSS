<script>
export default {}
</script>

<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="15"
    height="15"
    viewBox="0 0 15 15"
  >
    <g fill="none" fill-rule="evenodd">
      <g stroke="#2D2D2D" stroke-width="1.5" transform="translate(-227 -381)">
        <circle cx="234.5" cy="388.5" r="6.5" />
      </g>
    </g>
  </svg>
</template>

<style></style>
